.. frog documentation master file, created by
   sphinx-quickstart on Wed Jul  2 20:18:57 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

frog
####


.. toctree::
   :maxdepth: 2

.. automodule:: frog


Classes
=======

.. autoclass:: Frog
.. autoclass:: list_of
.. autoclass:: tuple_of
.. autoclass:: apply_all
.. autoclass:: items_of
.. autoclass:: expressions_of


Functions
=========

.. autofunction:: froglist
.. autofunction:: frogexec
.. autofunction:: isfrog
.. autofunction:: print_timings
.. autofunction:: sentence
.. autofunction:: eval_if_str


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
